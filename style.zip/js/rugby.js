
    var page = 1;
    function getRugby(pageDirection) {
      if (pageDirection == "next") {
        page++;
        $('#pageNo').html(page);
      }

      if (pageDirection == "previous") {
        page--;
        $('#pageNo').html(page);
      }
      $.getJSON({
        url: "https://content.guardianapis.com/search?page-size=6&show-fields=all&api-key=8193cdac-7310-49a5-9703-27ae3248d318&page=" +
        page +
        "&section=sport&q=rugby",
        error: function (xhr) { console.log("An error occured: " + xhr.status + " " + xhr.statusText); },
        success: function (data) {
          var results = data.response.results;
          $('.c24 .card-img-top').attr("src", results[0].fields.thumbnail);
          $('.c24 .headline').html(results[0].fields.headline);
          $('.c24 .trailText').html(results[0].fields.trailText);
          $(".c24 .firstPublicationDate").html(
            relativeDays(new Date(results[0].fields.firstPublicationDate).getTime())
          );
          $(".c24").attr("data-id", results[0].id);

          $('.c25 .card-img-top').attr("src", results[1].fields.thumbnail);
          $('.c25 .headline').html(results[1].fields.headline);
          $('.c25 .trailText').html(results[1].fields.trailText);
          $(".c25 .firstPublicationDate").html(
            relativeDays(new Date(results[1].fields.firstPublicationDate).getTime())
          );
          $(".c25").attr("data-id", results[1].id);

          $('.c26 .card-img-top').attr("src", results[2].fields.thumbnail);
          $('.c26 .headline').html(results[2].fields.headline);
          $('.c26 .trailText').html(results[2].fields.trailText);
          $(".c26 .firstPublicationDate").html(
            relativeDays(new Date(results[2].fields.firstPublicationDate).getTime())
          );
          $(".c26").attr("data-id", results[2].id);

          $('.c27 .card-img-top').attr("src", results[3].fields.thumbnail);
          $('.c27 .headline').html(results[3].fields.headline);
          $('.c27 .trailText').html(results[3].fields.trailText);
          $(".c27 .firstPublicationDate").html(
            relativeDays(new Date(results[3].fields.firstPublicationDate).getTime())
          );
          $(".c27").attr("data-id", results[3].id);

          $('.c28 .card-img-top').attr("src", results[4].fields.thumbnail);
          $('.c28 .headline').html(results[4].fields.headline);
          $('.c28 .trailText').html(results[4].fields.trailText);
          $(".c28 .firstPublicationDate").html(
            relativeDays(new Date(results[4].fields.firstPublicationDate).getTime())
          );
          $(".c28").attr("data-id", results[4].id);
        }

      });
    }

    $(document).ready(function () {
      getRugby();

      getRugby("");
      $("#rnext").click(function () {
        getRugby("next");
        return false;
      });

      $("#rprev").click(function () {
        getRugby("prev");
        return false;
      });
    });
