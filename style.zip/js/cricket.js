var page = 1;

function getCricket(pageDirection) {
  if (pageDirection == "next") {
    page++;
    $("#pageNo").html(page);
  }
  if (pageDirection == "previous" && page > "1") {
    page--;
    $("#pageNo").html(page);
  }

  $.getJSON({
    url:
      "https://content.guardianapis.com/search?page-size=5&show-fields=all&api-key=8193cdac-7310-49a5-9703-27ae3248d318&page=" +
      page +
      "&section=sport&q=cricket",
    error: function (xhr) {
      console.log("An error occured: " + xhr.status + " " + xhr.statusText);
    },
    success: function (data) {
      var results = data.response.results;
      $(".c14 .card-img-top").attr("src", results[0].fields.thumbnail);
      $(".c14 .headline").html(results[0].fields.headline);
      $(".c14 .trailText").html(results[0].fields.trailText);
      $(".c14 .firstPublicationDate").html(
        relativeDays(new Date(results[0].fields.firstPublicationDate).getTime())
      );
      $(".c14").attr("data-id", results[0].id);

      $(".c15 .card-img-top").attr("src", results[1].fields.thumbnail);
      $(".c15 .headline").html(results[1].fields.headline);
      $(".c15 .trailText").html(results[1].fields.trailText);
      $(".c15 .firstPublicationDate").html(
        relativeDays(new Date(results[1].fields.firstPublicationDate).getTime())
      );
      $(".c15").attr("data-id", results[1].id);

      $(".c16 .card-img-top").attr("src", results[2].fields.thumbnail);
      $(".c16 .headline").html(results[2].fields.headline);
      $(".c16 .trailText").html(results[2].fields.trailText);
      $(".c16 .firstPublicationDate").html(
        relativeDays(new Date(results[2].fields.firstPublicationDate).getTime())
      );
      $(".c16").attr("data-id", results[2].id);

      $(".c17 .card-img-top").attr("src", results[3].fields.thumbnail);
      $(".c17 .headline").html(results[3].fields.headline);
      $(".c17 .trailText").html(results[3].fields.trailText);
      $(".c17 .firstPublicationDate").html(
        relativeDays(new Date(results[0].fields.firstPublicationDate).getTime())
      );
      $(".c17").attr("data-id", results[3].id);

      $(".c18 .card-img-top").attr("src", results[4].fields.thumbnail);
      $(".c18 .headline").html(results[4].fields.headline);
      $(".c18 .trailText").html(results[4].fields.trailText);
      $(".c18 .firstPublicationDate").html(
        relativeDays(new Date(results[4].fields.firstPublicationDate).getTime())
      );
      $(".c18").attr("data-id", results[4].id);
    },
  });
}

$(document).ready(function () {
  getCricket();

  getCricket("");
  $("#cnext").click(function () {
    getCricket("next");
    return false;
  });

  $("#cprev").click(function () {
    getCricket("prev");
    return false;
  });

  $(".card").click(function () {
    getArticle(this.getAttribute("data-id"));
    console.log(this.getAttribute("data-id"));
  });
});


